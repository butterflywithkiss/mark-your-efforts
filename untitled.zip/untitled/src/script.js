// Get elements
const taskInput = document.getElementById("task-input");
const effortLevel = document.getElementById("effort-level");
const addTaskBtn = document.getElementById("add-task");
const taskList = document.getElementById("task-list");

// Load tasks from localStorage or start empty
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];
renderTasks();

// Add task
addTaskBtn.addEventListener("click", () => {
  const name = taskInput.value.trim();

  // Prevent empty or duplicate tasks
  if (name === "" || tasks.some((t) => t.name === name)) return;

  const task = {
    name: name,
    effort: effortLevel.value,
    done: false
  };

  tasks.push(task);
  saveTasks();
  taskInput.value = "";
  renderTasks();
});

// Save tasks to localStorage
function saveTasks() {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Render tasks
function renderTasks() {
  taskList.innerHTML = "";

  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.className = task.done ? "completed" : "";

    li.innerHTML = `
      <span>${task.name} - ${task.effort} min</span>
      <input type="checkbox" ${
        task.done ? "checked" : ""
      } data-index="${index}">
      <button class="delete-btn" data-index="${index}">Delete</button>
    `;

    taskList.appendChild(li);
  });

  // Checkbox event
  document.querySelectorAll("input[type=checkbox]").forEach((cb) => {
    cb.addEventListener("change", (e) => {
      const i = e.target.dataset.index;
      tasks[i].done = e.target.checked;
      saveTasks();
      renderTasks(); // re-render to apply completed class
    });
  });

  // Delete button event
  document.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      const i = e.target.dataset.index;
      tasks.splice(i, 1);
      saveTasks();
      renderTasks();
    });
  });
}
